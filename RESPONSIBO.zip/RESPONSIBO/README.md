# Aplikasi Manajemen Produk dan Transaksi

## Deskripsi Aplikasi
Aplikasi ini dirancang untuk mengelola produk dan mencatat transaksi penjualan. Aplikasi ini menggunakan Python dengan antarmuka grafis menggunakan Tkinter dan database MySQL untuk penyimpanan data.

## Cara Menjalankan Aplikasi
1. Pastikan MySQL sudah terinstal dan database `perusahaan_a` telah dibuat.
2. Gunakan file dump database `.sql` untuk mengimpor tabel `produk` dan `transaksi` ke dalam database.
3. Jalankan file `main.py` untuk membuka aplikasi.

## Struktur Tabel Database
- **Tabel produk**:
  - `id_produk` (Primary Key, Auto Increment)
  - `nama_produk` (VARCHAR)
  - `harga_produk` (DECIMAL)
- **Tabel transaksi**:
  - `id_transaksi` (Primary Key, Auto Increment)
  - `id_produk` (Foreign Key ke tabel produk)
  - `jumlah_produk` (INTEGER)
  - `total_harga` (DECIMAL)
  - `tanggal_transaksi` (DATE)
