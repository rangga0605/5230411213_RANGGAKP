import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector

# Koneksi ke database
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="retail_db"
    )

# Fungsi CRUD untuk produk
def create_product(nama_produk, harga_produk):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO produk (nama_produk, harga_produk) VALUES (%s, %s)", (nama_produk, harga_produk))
    conn.commit()
    conn.close()

def read_products():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM produk")
    data = cursor.fetchall()
    conn.close()
    return data

def update_product(id_produk, nama_produk, harga_produk):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE produk SET nama_produk = %s, harga_produk = %s WHERE id_produk = %s", (nama_produk, harga_produk, id_produk))
    conn.commit()
    conn.close()

def delete_product(id_produk):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM produk WHERE id_produk = %s", (id_produk,))
    conn.commit()
    conn.close()

# Fungsi CRUD untuk transaksi
def create_transaction(id_produk, jumlah_produk, total_harga, tanggal_transaksi):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO transaksi (id_produk, jumlah_produk, total_harga, tanggal_transaksi) VALUES (%s, %s, %s, %s)", 
                   (id_produk, jumlah_produk, total_harga, tanggal_transaksi))
    conn.commit()
    conn.close()

def read_transactions():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM transaksi")
    data = cursor.fetchall()
    conn.close()
    return data

def delete_transaction(id_transaksi):
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM transaksi WHERE id_transaksi = %s", (id_transaksi,))
    conn.commit()
    conn.close()

# GUI Aplikasi
class AplikasiApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Manajemen Produk dan Transaksi")
        
        self.tabs = ttk.Notebook(root)
        self.tabs.pack(expand=1, fill="both")
        
        self.create_produk_tab()
        self.create_transaksi_tab()

    def create_produk_tab(self):
        produk_tab = ttk.Frame(self.tabs)
        self.tabs.add(produk_tab, text="Produk")
        
        self.tree_produk = ttk.Treeview(produk_tab, columns=("ID", "Nama", "Harga"), show='headings')
        self.tree_produk.heading("ID", text="ID")
        self.tree_produk.heading("Nama", text="Nama Produk")
        self.tree_produk.heading("Harga", text="Harga")
        self.tree_produk.pack(fill="both", expand=1)
        
        self.refresh_produk()
        
        self.nama_produk_entry = tk.Entry(produk_tab)
        self.nama_produk_entry.pack()
        
        self.harga_produk_entry = tk.Entry(produk_tab)
        self.harga_produk_entry.pack()
        
        tk.Button(produk_tab, text="Tambah Produk", command=self.add_product).pack()
        tk.Button(produk_tab, text="Hapus Produk", command=self.delete_product_gui).pack()
        
    def refresh_produk(self):
        for row in self.tree_produk.get_children():
            self.tree_produk.delete(row)
        
        for produk in read_products():
            self.tree_produk.insert("", tk.END, values=produk)
    
    def add_product(self):
        nama = self.nama_produk_entry.get()
        harga = self.harga_produk_entry.get()
        
        if nama and harga.isdigit():
            harga = float(harga)
            create_product(nama, harga)
            self.refresh_produk()
            self.nama_produk_entry.delete(0, tk.END)
            self.harga_produk_entry.delete(0, tk.END)
        else:
            messagebox.showerror("Error", "Silakan masukkan nama produk dan harga yang valid.")

    def delete_product_gui(self):
        selected_item = self.tree_produk.selection()[0]
        id_produk = self.tree_produk.item(selected_item, 'values')[0]
        
        delete_product(id_produk)
        self.refresh_produk()

    def create_transaksi_tab(self):
        transaksi_tab = ttk.Frame(self.tabs)
        self.tabs.add(transaksi_tab, text="Transaksi")
        
        self.tree_transaksi = ttk.Treeview(transaksi_tab, columns=("ID", "Produk", "Jumlah", "Total", "Tanggal"), show='headings')
        self.tree_transaksi.heading("ID", text="ID")
        self.tree_transaksi.heading("Produk", text="Nama Produk")
        self.tree_transaksi.heading("Jumlah", text="Jumlah")
        self.tree_transaksi.heading("Total", text="Total Harga")
        self.tree_transaksi.heading("Tanggal", text="Tanggal Transaksi")
        self.tree_transaksi.pack(fill="both", expand=1)
        
        self.refresh_transaksi()
        
        self.id_produk_entry = ttk.Combobox(transaksi_tab, values=[prod[1] for prod in read_products()])
        self.id_produk_entry.pack()
        
        self.jumlah_produk_entry = tk.Entry(transaksi_tab)
        self.jumlah_produk_entry.pack()
        
        self.tanggal_transaksi_entry = tk.Entry(transaksi_tab)
        self.tanggal_transaksi_entry.pack()
        
        tk.Button(transaksi_tab, text="Tambah Transaksi", command=self.add_transaction).pack()
        tk.Button(transaksi_tab, text="Hapus Transaksi", command=self.delete_transaction_gui).pack()
    
    def refresh_transaksi(self):
        for row in self.tree_transaksi.get_children():
            self.tree_transaksi.delete(row)
        
        for transaksi in read_transactions():
            self.tree_transaksi.insert("", tk.END, values=transaksi)

    def add_transaction(self):
        id_produk = self.id_produk_entry.get()
        jumlah = self.jumlah_produk_entry.get()
        tanggal = self.tanggal_transaksi_entry.get()
        
        if id_produk and jumlah.isdigit() and tanggal:
            id_produk = int(id_produk)
            jumlah = int(jumlah)
            create_transaction(id_produk, jumlah, id_produk * jumlah, tanggal)
            self.refresh_transaksi()
        else:
            messagebox.showerror("Error", "Silakan masukkan data transaksi yang valid.")

    def delete_transaction_gui(self):
        selected_item = self.tree_transaksi.selection()[0]
        id_transaksi = self.tree_transaksi.item(selected_item, 'values')[0]
        
        delete_transaction(id_transaksi)
        self.refresh_transaksi()

# Menjalankan aplikasi
if __name__ == "__main__":
    root = tk.Tk()
    app = AplikasiApp(root)
    root.mainloop()
